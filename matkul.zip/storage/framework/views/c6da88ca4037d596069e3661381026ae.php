<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.5.1/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel='stylesheet'
        href='https://cdn-uicons.flaticon.com/2.5.1/uicons-bold-straight/css/uicons-bold-straight.css'>
    <link rel='stylesheet'
        href='https://cdn-uicons.flaticon.com/2.5.1/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel='stylesheet'
        href='https://cdn-uicons.flaticon.com/2.5.1/uicons-solid-straight/css/uicons-solid-straight.css'>

    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        /* Sidebar collapse styles */
        #sidebar {
            transition: width 0.3s ease;
        }

        #sidebar.w-20 {
            width: 5rem;
            /* Width when collapsed */
        }

        /* Initially hide dropdown */
        .hidden {
            display: none;
        }

        /* Dropdown menu styling */
        .dropdown-menu {
            padding-left: 1rem;
        }

        /* Ensure icons are adjusted in collapsed state */
        #sidebar.w-20 .dropdown-menu {
            padding-left: 0.5rem;
        }
    </style>
</head>

<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-100 dark:bg-gray-900 flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-white dark:bg-gray-800 shadow-md" id="sidebar">
            <div class="p-4">
                <h2 class="text-lg font-semibold text-gray-700 dark:text-gray-200">
                    <?php echo e($matkul->MataKuliah); ?></h2>
                <ul class="mt-4 space-y-2">
                    <!-- Dropdown Menu -->
                    <?php $__currentLoopData = $pertemuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="#"
                                class="flex items-center p-2 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-md dropdown-toggle">
                                <i class="fi fi-sr-chalkboard-user mr-4 mt-1"></i>
                                Pertemuan <?php echo e($p->pertemuan); ?>

                            </a>
                            <ul class="dropdown-menu hidden pl-6 space-y-2">
                                <?php $__currentLoopData = $materi->where('KodePertemuan', $p->KodePertemuan); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('mahasiswa.edit', $m->KodeMateri)); ?>"
                                            class="flex items-center p-2 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-md">
                                            <i class="fi fi-sr-circle mr-4 mt-1"></i> <?php echo e($m->judul); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </aside>

        <!-- Button to collapse sidebar -->
        <button id="sidebar-toggle"
            class="p-2 text-gray-700 bg-red-500 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">
            <i class="fi fi-br-arrow-left-circle"></i>
        </button>

        <!-- Main Content -->
        <div class="flex-1">
            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white dark:bg-gray-800 shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <iframe src="<?php echo e(url('materi/' . $file->materi)); ?>"
                    style="width: 100%; height: 100vh;"
                    frameborder="0"
                    allowfullscreen></iframe>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

    <script>
        $(document).ready(function() {
            // Toggle dropdown
            $('.dropdown-toggle').on('click', function() {
                $(this).next('.dropdown-menu').toggleClass('hidden');
            });

            // Collapse/expand sidebar
            $('#sidebar-toggle').on('click', function() {
                $('#sidebar').toggleClass('w-64 w-20'); // Change the width of the sidebar
            });
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\LP3I\PA AZKA\trace-study\resources\views/page/mahasiswa/show.blade.php ENDPATH**/ ?>